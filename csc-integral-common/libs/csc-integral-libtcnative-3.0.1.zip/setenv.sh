#!/bin/bash

KERNEL=`uname -s`
PROCESSOR=`uname -p`

# Absolute path of dir containing this script
CONTAINING_DIR=`dirname $0`
CONTAINING_DIR=`cd $CONTAINING_DIR; pwd`

echo "See if we have Tomcat Native Library for the current OS"
echo -e "OS is $KERNEL $PROCESSOR \c"

SUPPORTED=false
if [ "$KERNEL" = "Linux" -a "$PROCESSOR" = "x86_64" ]; then
    SUPPORTED=true
    LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$CONTAINING_DIR/libtcnative-1.1.20-el5-x86_64
fi

if [ "$KERNEL" = "SunOS" -a "$PROCESSOR" = "sparc" ]; then
    SUPPORTED=true
    LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$CONTAINING_DIR/libtcnative-1.1.20-solaris-sparc
fi

if [ "$SUPPORTED" = "true" ]; then
    echo "(Tomcat Native Library is supported)"
    echo "Set LD_LIBRARY_PATH=$LD_LIBRARY_PATH"
    export LD_LIBRARY_PATH
else
    echo "(Tomcat Native Library is NOT supported, performance will not be optimal for production environment)"
fi
